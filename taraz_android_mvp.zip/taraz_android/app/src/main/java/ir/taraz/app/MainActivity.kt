package ir.taraz.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private val Ink = Color(0xFF132238)
private val Green = Color(0xFF159A76)
private val Pale = Color(0xFFF4F7F9)
private val Muted = Color(0xFF738195)
private val Gold = Color(0xFFE3B65B)
private val Red = Color(0xFFD96D72)

enum class AssetKind(val title: String) {
    CASH("پول نقد"), BANK("حساب بانکی"), GOLD("طلا"), FX("ارز")
}
data class Asset(val id: Long, val name: String, val kind: AssetKind, val quantity: Double, val unitPrice: Long) {
    val value: Long get() = (quantity * unitPrice).toLong()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TarazApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TarazApp() {
    var assets by remember {
        mutableStateOf(
            listOf(
                Asset(1, "حساب اصلی", AssetKind.BANK, 1.0, 45_000_000),
                Asset(2, "پول نقد", AssetKind.CASH, 1.0, 3_500_000),
                Asset(3, "طلای ۱۸ عیار", AssetKind.GOLD, 5.0, 4_250_000),
                Asset(4, "دلار آمریکا", AssetKind.FX, 500.0, 82_000)
            )
        )
    }
    var showAdd by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) }
    val total = assets.sumOf { it.value }
    val money = remember { NumberFormat.getNumberInstance(Locale("fa", "IR")) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Pale,
            surface = Color.White,
            onSurface = Ink,
            secondary = Gold
        )
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("تراز", fontWeight = FontWeight.Bold, fontSize = 23.sp, color = Ink)
                            Text("مدیریت هوشمند دارایی", fontSize = 12.sp, color = Muted)
                        }
                    },
                    actions = {
                        IconButton(onClick = { /* قفل بیومتریک در مرحله امنیت اضافه می‌شود */ }) {
                            Icon(Icons.Default.Security, contentDescription = "امنیت", tint = Ink)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }, containerColor = Green, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "افزودن دارایی")
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Wallet, contentDescription = null) },
                        label = { Text("دارایی‌ها") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.AutoGraph, contentDescription = null) },
                        label = { Text("گزارش‌ها") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.CurrencyExchange, contentDescription = null) },
                        label = { Text("بازار") }
                    )
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> AssetsScreen(
                    modifier = Modifier.padding(padding),
                    assets = assets,
                    total = total,
                    money = money,
                    onDelete = { id -> assets = assets.filterNot { it.id == id } }
                )
                1 -> ReportsScreen(Modifier.padding(padding), assets, total, money)
                else -> MarketScreen(Modifier.padding(padding))
            }
        }

        if (showAdd) {
            AddAssetDialog(
                onDismiss = { showAdd = false },
                onAdd = { name, kind, quantity, unitPrice ->
                    assets = assets + Asset(System.currentTimeMillis(), name, kind, quantity, unitPrice)
                    showAdd = false
                }
            )
        }
    }
}

@Composable
fun AssetsScreen(
    modifier: Modifier,
    assets: List<Asset>,
    total: Long,
    money: NumberFormat,
    onDelete: (Long) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 100.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Ink),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("مجموع دارایی شما", color = Color(0xFFB9C7D8), fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("${money.format(total)} تومان", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoGraph, contentDescription = null, tint = Color(0xFF55D6A5), modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("ارزش بر اساس مقادیر ثبت‌شده", color = Color(0xFF55D6A5), fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                SummaryTile("حساب و نقد", money.format(assets.filter { it.kind == AssetKind.BANK || it.kind == AssetKind.CASH }.sumOf { it.value }), Modifier.weight(1f))
                SummaryTile("طلا و ارز", money.format(assets.filter { it.kind == AssetKind.GOLD || it.kind == AssetKind.FX }.sumOf { it.value }), Modifier.weight(1f))
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("دارایی‌های من", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
                Spacer(Modifier.weight(1f))
                Text("${assets.size} مورد", color = Muted, fontSize = 12.sp)
            }
        }
        if (assets.isEmpty()) {
            item { Text("هنوز دارایی‌ای ثبت نکرده‌اید. برای شروع دکمه + را بزنید.", color = Muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(24.dp)) }
        }
        items(assets, key = { it.id }) { asset ->
            AssetRow(asset, money, onDelete)
        }
    }
}

@Composable
fun SummaryTile(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(7.dp))
            Text("$value تومان", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink)
        }
    }
}

@Composable
fun AssetRow(asset: Asset, money: NumberFormat, onDelete: (Long) -> Unit) {
    val iconColor = when (asset.kind) {
        AssetKind.CASH -> Green
        AssetKind.BANK -> Color(0xFF4F91D8)
        AssetKind.GOLD -> Gold
        AssetKind.FX -> Color(0xFF9673D4)
    }
    Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(44.dp).background(iconColor.copy(alpha = .13f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = when (asset.kind) {
                        AssetKind.BANK -> Icons.Default.AccountBalance
                        AssetKind.CASH -> Icons.Default.Wallet
                        AssetKind.GOLD -> Icons.Default.AutoGraph
                        AssetKind.FX -> Icons.Default.CurrencyExchange
                    },
                    contentDescription = null, tint = iconColor
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(asset.name, fontWeight = FontWeight.SemiBold, color = Ink)
                Text("${asset.kind.title} • مقدار ${asset.quantity}", color = Muted, fontSize = 12.sp)
                Text("هر واحد: ${money.format(asset.unitPrice)} تومان", color = Muted, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(money.format(asset.value), fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp)
                TextButton(onClick = { onDelete(asset.id) }, contentPadding = PaddingValues(0.dp)) {
                    Text("حذف", color = Red, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(modifier: Modifier, assets: List<Asset>, total: Long, money: NumberFormat) {
    val kinds = AssetKind.values().toList()
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("گزارش ترکیب دارایی", fontWeight = FontWeight.Bold, fontSize = 21.sp, color = Ink)
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(18.dp)) {
                Text("تقسیم دارایی بر اساس نوع", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                if (total > 0L) {
                    Canvas(Modifier.fillMaxWidth().height(18.dp)) {
                        val colors = listOf(Green, Color(0xFF4F91D8), Gold, Color(0xFF9673D4))
                        var start = 0f
                        kinds.forEachIndexed { index, kind ->
                            val amount = assets.filter { it.kind == kind }.sumOf { it.value }.toFloat()
                            val sweep = size.width * amount / total.toFloat()
                            drawRoundRect(colors[index], topLeft = androidx.compose.ui.geometry.Offset(start, 0f),
                                size = androidx.compose.ui.geometry.Size(sweep.coerceAtLeast(0f), size.height),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f))
                            start += sweep
                        }
                    }
                } else {
                    Text("برای نمایش گزارش، ابتدا دارایی ثبت کنید.", color = Muted)
                }
                Spacer(Modifier.height(18.dp))
                kinds.forEachIndexed { index, kind ->
                    val value = assets.filter { it.kind == kind }.sumOf { it.value }
                    val percent = if (total > 0) value * 100.0 / total else 0.0
                    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(listOf(Green, Color(0xFF4F91D8), Gold, Color(0xFF9673D4))[index], CircleShape))
                        Spacer(Modifier.width(8.dp))
                        Text(kind.title, color = Ink, modifier = Modifier.weight(1f))
                        Text("${String.format(Locale.US, "%.1f", percent)}٪", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.width(10.dp))
                        Text("${money.format(value)} تومان", color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
            }
        }
        Text("این گزارش بر اساس دارایی‌های فعلی ثبت‌شده محاسبه می‌شود. تاریخچه تغییرات قیمت در نسخه بعدی افزوده می‌شود.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun MarketScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("بازار ارز و طلا", fontWeight = FontWeight.Bold, fontSize = 21.sp, color = Ink)
        Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("قیمت‌ها هنوز به منبع آنلاین وصل نشده‌اند.", fontWeight = FontWeight.SemiBold, color = Ink)
                Text("در نسخه آزمایشی، قیمت واحد هر دارایی هنگام ثبت به‌صورت دستی وارد می‌شود. برای قیمت لحظه‌ای باید منبع داده و API معتبر انتخاب شود.", color = Muted, fontSize = 13.sp)
            }
        }
        Text("پیشنهاد برای مرحله بعد", fontWeight = FontWeight.Bold, color = Ink)
        Text("• انتخاب منبع قیمت ارز و طلای ایران\n• نمایش زمان آخرین به‌روزرسانی\n• امکان تازه‌سازی قیمت‌ها و محاسبه مجدد ارزش دارایی", color = Muted, lineHeight = 24.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddAssetDialog(
    onDismiss: () -> Unit,
    onAdd: (String, AssetKind, Double, Long) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(AssetKind.BANK) }
    var quantity by remember { mutableStateOf("1") }
    var price by remember { mutableStateOf("") }
    var kindMenu by remember { mutableStateOf(false) }
    val qty = quantity.toDoubleOrNull()
    val unitPrice = price.toLongOrNull()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن دارایی", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("نام دارایی") }, singleLine = true)
                ExposedDropdownMenuBox(expanded = kindMenu, onExpandedChange = { kindMenu = !kindMenu }) {
                    OutlinedTextField(
                        value = kind.title, onValueChange = {}, readOnly = true,
                        label = { Text("نوع دارایی") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = kindMenu) },
                        modifier = Modifier.menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = kindMenu, onDismissRequest = { kindMenu = false }) {
                        AssetKind.values().forEach { option ->
                            DropdownMenuItem(text = { Text(option.title) }, onClick = { kind = option; kindMenu = false })
                        }
                    }
                }
                OutlinedTextField(
                    value = quantity, onValueChange = { quantity = it },
                    label = { Text("مقدار (برای پول و حساب ۱)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true
                )
                OutlinedTextField(
                    value = price, onValueChange = { price = it.filter(Char::isDigit) },
                    label = { Text("قیمت هر واحد به تومان") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true
                )
                Text("برای حساب بانکی یا پول نقد، مقدار را ۱ و قیمت را برابر موجودی وارد کنید.", color = Muted, fontSize = 11.sp)
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank() && qty != null && qty > 0 && unitPrice != null && unitPrice >= 0,
                onClick = { onAdd(name.trim(), kind, qty!!, unitPrice!!) }
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
